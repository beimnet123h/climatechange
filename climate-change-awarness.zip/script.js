/* .js files add interaction to your website */
/*
KEY FEATURE: Personalize it
https://stackoverflow.com/questions/26107125/cannot-read-property-addeventlistener-of-null
*/

var displayScript = document.getElementById("scriptReturned");
var scriptBtn = document.getElementById("scriptBtn");
//Will need to explain that sometimes the DOM doesn't load all the way, so the browser can't find the element for JavaScript to use

if (scriptBtn) {
  scriptBtn.addEventListener("click", generateScript);
}

/*
REFACTOR ITEM 2: 
Create a separate function for displaying the script.
Be sure to update function names.
*/


//Move these variables to the top
var factList = [
  "The worst impacts of climate change could be irreversible by 2030", 
  "The 20 warmest years on record have been in the past 22 years", 
  "More than 1 million species are at risk of extinction by climate change", 
  "A warming world also increases the intensity of natural disasters.", 
  "Countries contributing most to global emissions have the best chance of curbing climate change, but leaders are doing little to address it.", 
  "The United States is the second largest contributor to carbon dioxide (CO2) in our atmosphere"
];

var fact = document.getElementById("fact");
var factBtn = document.getElementById("factBtn");
var count = 0;

if (factBtn) {
  factBtn.addEventListener("click", displayFact);
}

function displayFact() {
  fact.innerHTML = factList[count];
  count++;
  if (count == factList.length) {
    count = 0;
  }
}

